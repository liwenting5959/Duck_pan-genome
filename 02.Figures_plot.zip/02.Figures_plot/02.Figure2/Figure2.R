#Author: Kejun Wang
#Email: wangkejun.me@163.com

setwd("/Your/Path/Here")
##################
### Figure2A-B ###
##################
library(ggplot2)
library(tidyverse)
library(readxl)
the <- theme(#legend.position = "none",
  panel.grid.major = element_blank(),
  panel.grid.minor = element_blank(),
  panel.border = element_blank(),
  panel.background = element_blank(),
  legend.title = element_blank(),
  legend.text = element_text(size = 10, face = "bold.italic"),
  legend.key.height=unit(2,"line"),
  axis.line = element_blank(),
  axis.ticks = element_line(size = 1, colour = "black"),
  axis.ticks.length=unit(.15, "cm"),
  axis.title.x = element_text(face = "bold", size = 15, colour = "black"),
  axis.title.y = element_text(face = "bold", size = 15, colour = "black"),
  axis.text.x = element_text(size = 10,angle = 0, vjust = 0, face = "bold", colour = "black"), 
  axis.text.y = element_text(face = "bold", size = 10, colour = "black"),
  axis.line.x = element_line(colour = "black", size = 0.6),
  axis.line.y = element_line(colour = "black", size = 0.6),
  plot.margin = margin(t = 1, r = 1, b = 0.5, l = 0.5, unit = "cm"))

##c('#BF0B3B','#D50DD9','#1835D9','#238C2A','#F2B90C')


myclour_Set1 <-c('#BF0B3B','#F2B90C','#D50DD9','#1835D9')
myclour_Set2 <- c('#BF0B3B','#238C2A','#F2B90C','#D50DD9','#1835D9')

###mallard_vs_native
#data reading
mydata<-read_excel("./data/Data.xlsx",sheet = "Figure 2A")
mydata<-data.frame(mydata)
mydata <-mydata%>%
  mutate(.,fdr_class = 1)
mydata[mydata$p_adjusted_FDR >= 0.001,]$fdr_class<-'>=0.001'
mydata[mydata$p_adjusted_FDR < 0.001 & mydata$p_adjusted_FDR >1e-5,]$fdr_class<-'<0.001'
mydata[mydata$p_adjusted_FDR < 1e-5 & mydata$p_adjusted_FDR >1e-10,]$fdr_class<-'<1e-5'
mydata[mydata$p_adjusted_FDR < 1e-10,]$fdr_class<-'<1e-10'
mydata[mydata$p_adjusted_FDR < 1e-15,]$fdr_class<-'<1e-15'
mydata<- mydata[order(mydata$fdr_class,decreasing = TRUE),]
p<-ggplot(data=mydata,mapping=aes(y=Wild_group_frequency,x=Native_group_frequency,colour=factor(fdr_class)))
p1=p+geom_point(size =2,alpha=1,shape=16)+theme_classic() + the+xlab("Frequency of Native")+ylab("Frequency of Wild")+
  scale_color_manual(values =myclour_Set2)
p1

###native_vs_pekin
mydata<-read_excel("./data/Data.xlsx",sheet = "Figure 2B")
mydata<-data.frame(mydata)
mydata <-mydata%>%
  mutate(.,fdr_class = 1)
mydata[mydata$p_adjusted_FDR >= 0.001,]$fdr_class<-'>=0.001'
mydata[mydata$p_adjusted_FDR < 0.001 & mydata$p_adjusted_FDR >1e-5,]$fdr_class<-'<0.001'
mydata[mydata$p_adjusted_FDR < 1e-5 & mydata$p_adjusted_FDR >1e-10,]$fdr_class<-'<1e-5'
mydata[mydata$p_adjusted_FDR < 1e-10,]$fdr_class<-'<1e-10'
mydata[mydata$p_adjusted_FDR < 1e-15,]$fdr_class<-'<1e-15'
mydata<- mydata[order(mydata$fdr_class,decreasing = TRUE),]
p<-ggplot(data=mydata,mapping=aes(y=Native_group_frequency,x=Commercial_group_frequency,colour=factor(fdr_class)))
p2=p+geom_point(size =2,alpha=1,shape=16)+theme_classic() + the+xlab("Frequency of Commercial")+ylab("Frequency of Native")+
  scale_color_manual(values =myclour_Set2)
p2




##################
### Figure2C-D ###
##################

library(CMplot)
library(dplyr)
library(stringr)
library(ggplot2)
variant_info<-read.csv("variant.info",header = FALSE,sep=" ")
colnames(variant_info) <-c("sv_id1","sv_id2")
mytheme <-  theme(panel.grid.major = element_blank(),
                  panel.grid.minor = element_blank(),
                  panel.border = element_blank(),
                  panel.background = element_blank(),
                  legend.title = element_blank(),
                  legend.text = element_text(size = 10, face = "bold.italic"),
                  legend.key.height=unit(2,"line"),
                  axis.line = element_blank(),
                  axis.ticks = element_line(size = 1, colour = "black"),
                  axis.ticks.length=unit(.15, "cm"),
                  axis.title.x = element_text(face = "bold", size = 15, colour = "black"),
                  axis.title.y = element_text(face = "bold", size = 15, colour = "black"),
                  axis.text.x = element_text(size = 10,angle = 0, vjust = 0, face = "bold", colour = "black"), 
                  axis.text.y = element_text(face = "bold", size = 10, colour = "black"),
                  axis.line.x = element_line(colour = "black", size = 0.6),
                  axis.line.y = element_line(colour = "black", size = 0.6),
                  plot.margin = margin(t = 1, r = 1, b = 0.5, l = 0.5, unit = "cm"))

#NativevsWild
Sub1_fst <- read.table("fst_native_Vs_wild.weir.fst",header = TRUE,sep="\t",row.names = NULL,fill=NA)
Sub1_fst <-Sub1_fst %>% mutate(SNP = paste0(Sub1_fst$CHROM,"_",Sub1_fst$POS))
Sub1_fst <- na.omit(Sub1_fst)
Sub1_fst <-Sub1_fst[, c(4,1,2,3)]
#output sig loci
#top 1%
line99<-quantile(Sub1_fst$WEIR_AND_COCKERHAM_FST,0.99)
Sub1_fst_sig<-Sub1_fst[Sub1_fst$WEIR_AND_COCKERHAM_FST >= line99,]
Sub1_fst_sig<-Sub1_fst_sig %>% left_join(variant_info, by= c('SNP' = 'sv_id1'))
CMplot(Sub1_fst,plot.type="m",chr.den.col=NULL,col=c("#238C2A","#F2B90C","#D50DD9"),LOG10=FALSE,ylab="FST(Native_Vs_Wild)",threshold=line99,signal.col=c("#BF0B3B","#1835D9"),amplify=TRUE, signal.cex=c(0.8),file="pdf",memo="FST_Native_Vs_Wild_top0.01",cex=0.5,ylim=NULL,dpi=600)
CMplot(Sub1_fst,plot.type="m",chr.den.col=NULL,col=c("#238C2A","#F2B90C","#D50DD9"),LOG10=FALSE,ylab="FST(Native_Vs_Wild)",threshold=line99,signal.col=c("#BF0B3B","#1835D9"),amplify=TRUE, signal.cex=c(0.8),file="jpg",memo="FST_Native_Vs_Wild_top0.01",cex=0.5,ylim=NULL,dpi=600)

#ComvsNative
Sub2_fst <- read.table("fst_com_Vs_native.weir.fst",header = TRUE,sep="\t",row.names = NULL,fill=NA)
Sub2_fst <- Sub2_fst %>% mutate(SNP = paste0(Sub2_fst$CHROM,"_",Sub2_fst$POS))
Sub2_fst <- na.omit(Sub2_fst)
Sub2_fst <-Sub2_fst[, c(4,1,2,3)]
#output fig
#top 1%
line99<-quantile(Sub2_fst$WEIR_AND_COCKERHAM_FST,0.99)
Sub2_fst_sig<-Sub2_fst[Sub2_fst$WEIR_AND_COCKERHAM_FST >= line99,]
Sub2_fst_sig<-Sub2_fst_sig %>% left_join(variant_info, by= c('SNP' = 'sv_id1'))
CMplot(Sub2_fst,plot.type="m",chr.den.col=NULL,col=c("#238C2A","#F2B90C","#D50DD9"),LOG10=FALSE,ylab="FST(Com_Vs_Native)",threshold=line99,signal.col=c("#BF0B3B","#1835D9"),amplify=TRUE, signal.cex=c(0.8),file="pdf",memo="FST_Com_Vs_Native_top0.01",cex=0.5,ylim=NULL,dpi=600)
CMplot(Sub2_fst,plot.type="m",chr.den.col=NULL,col=c("#238C2A","#F2B90C","#D50DD9"),LOG10=FALSE,ylab="FST(Com_Vs_Native)",threshold=line99,signal.col=c("#BF0B3B","#1835D9"),amplify=TRUE, signal.cex=c(0.8),file="jpg",memo="FST_Com_Vs_Native_top0.01",cex=0.5,ylim=NULL,dpi=600)


