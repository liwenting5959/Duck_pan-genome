#Author: Kejun Wang
#Email: wangkejun.me@163.com

setwd("/Your/Path/Here")

##################
### Figure3A ###
##################

#####################Gene structure plot########################
###domestication
df<-read.table('./data/pan_final_sig_dom_svTE_gff.txt',sep ='\t')
df<-df[,c(1,4,5,9)]
colnames(df) <- c("chr","start","end",'gene')
df1 <-separate(df,col=chr,into=c('lineid',"chr1"),sep=':')
df3<-df1[,c("chr1","start","end",'gene')]

#TRNAK-CUU
df3_1 <-df3[df3$gene == "TRNAK-CUU",]
df3_1_sv<-data.frame(
  x=c(161936.078,161943.734),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00035449","DEL00035449"))
p1 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "TRNAK-CUU")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p1
#PRKN
df3_1 <-df3[df3$gene == "PRKN",]
df3_1_sv<-data.frame(
  x=c(48319.908,48327.099),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00074334"," "))
p2 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "PRKN")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p2
#LRP1B
df3_1 <-df3[df3$gene == "LRP1B",]
df3_1_sv<-data.frame(
  x=c(5333.785,5338.565),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00109585"," "))
p3 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "LRP1B")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p3
#"LOC101801770(shugoshin 2)
df3_1 <-df3[df3$gene == "LOC101801770(shugoshin 2)",]
df3_1_sv<-data.frame(
  x=c(25650.785,25653.667),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00111478"," "))
p4 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "LOC101801770(shugoshin 2)")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p4
#LOC119717947
df3_1 <-df3[df3$gene == "LOC119717947",]
df3_1_sv<-data.frame(
  x=c(521.998,529.037),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("INV00121661"," "))
p5 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "LOC119717947")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p5
#ERC2
df3_1 <-df3[df3$gene == "ERC2",]
df3_1_sv<-data.frame(
  x=c(22237.731,22245.126),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00132422"," "))
p6 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "ERC2")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p6
#TPM4
df3_1 <-df3[df3$gene == "TPM4",]
df3_1_sv<-data.frame(
  x=c(2364.976,2372.450),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00155768"," "))
p7 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "TPM4")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p7
require(gridExtra)
grid.arrange(p1,p2,p3,p4,p5,p6,p7,ncol=1)

####improvement
df<-read.table('./data/pan_final_sig_impro_svTE_gff.txt',sep ='\t')
df<-df[,c(1,4,5,9)]
colnames(df) <- c("chr","start","end",'gene')
df1 <-separate(df,col=chr,into=c('lineid',"chr1"),sep=':')
df3<-df1[,c("chr1","start","end",'gene')]

#ADCYAP1R1
df3_1 <-df3[df3$gene == "ADCYAP1R1",]
df3_1_sv<-data.frame(
  x=c(161957.648,161965.013),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c(" ","DEL00035449"))
p1 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "ADCYAP1R1")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p1
#MACROD2
df3_1 <-df3[df3$gene == "MACROD2",]
df3_1_sv<-data.frame(
  x=c(7550.530,7557.983),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00069030"," "))
p2 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "MACROD2")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p2
#QKI
df3_1 <-df3[df3$gene == "QKI",]
df3_1_sv<-data.frame(
  x=c(47527.245,47534.356
  ),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00074234"," "))
p3 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "QKI")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p3
#LOC110351803
df3_1 <-df3[df3$gene == "LOC110351803",]
df3_1_sv<-data.frame(
  x=c(27499.806,27506.386),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("","DEL00099489 "))
p4 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "LOC110351803")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p4
#FN1
df3_1 <-df3[df3$gene == "FN1",]
df3_1_sv<-data.frame(
  x=c(31115.374,31122.849),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00112024"," "))
p5 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "FN1")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p5
#MITF
df3_1 <-df3[df3$gene == "MITF",]
df3_1_sv<-data.frame(
  x=c(5220.761,5227.457),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00130156"," "))
p6 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "MITF")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p6
#IGF2BP1
df3_1 <-df3[df3$gene == "IGF2BP1",]
df3_1_sv<-data.frame(
  x=c(113.029,120.138),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00154411"," "))
p7 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "IGF2BP1")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p7
#AN1-type zinc finger protein 5
df3_1 <-df3[df3$gene == "AN1-type zinc finger protein 5",]
df3_1_sv<-data.frame(
  x=c(4746.921,4754.166),
  ymin=c(0,0),
  ymax=c(0.081,0.081),
  txt=c("DEL00156212"," "))
p8 <- ggplot() + 
  geom_point(data=df3_1_sv,aes(x=x,y=ymax),color="BLUE",size=8)+
  geom_linerange(data=df3_1_sv,aes(x=x,ymin=ymin,ymax=ymax),color="BLUE")+
  geom_hline(yintercept=0)+
  geom_text(data=df3_1_sv,aes(x=x,y=ymax+ 0.01,label=txt,size=8))+
  geom_rect(data=df3_1,aes(xmin=start/1000, xmax=end/1000,ymin= -0.05,ymax=0.05),fill="#282a73")+
  labs(title=" ",subtitle = "AN1-type zinc finger protein 5")+
  ggplot2::theme(
    title = element_text(size=18,face="bold"),
    axis.title = element_blank(),
    axis.text.x = element_text(color = "black",angle = 0,size=12),
    axis.text.y= element_blank(),
    axis.ticks.x= element_line(colour = "black"),
    axis.ticks.y=element_blank(),
    panel.grid =element_blank(),
    panel.background = element_blank(),
    panel.border=element_blank(),
    legend.position = "none")
p8
require(gridExtra)
grid.arrange(p1,p2,p3,p4,p5,p6,p7,p8,ncol=1)

#####################Chromosome structure plot########################
library(tidyverse)
require(RIdeogram)

#make TE file
te<-read.table("./data/pan_TE.used.list",header=FALSE,sep='\t')
colnames(te)<-c("Chr","Start","End","Value_1")
te$Color_1 <-'238C2A'
#make SV file
sv<-read.delim('./data/pan_gene_sv.used.list',header=FALSE)
colnames(sv)<-c("Chr","Start","End","Value_2")
sv$Color_2 <-'F2B90C'
sv<-sv[,c("Value_2","Color_2")]
duck_marker <-cbind.data.frame(te,sv)
class(duck_marker$Start)
write.csv(duck_marker,"./data/duck_TE_Sv_marker.csv",quote=FALSE,row.names = FALSE)
#reading file
duck_marker<-read.csv("./data/duck_TE_Sv_marker.csv",header = TRUE)
duck_marker<-duck_marker[duck_marker$Chr <= 32,]
#make karyotype file
duck_karyotype <-read.delim('./data/pan_final.fa.fai_for_chromomap',header=FALSE)
colnames(duck_karyotype)<-c("Chr","End")
duck_karyotype$Start <- 0
duck_karyotype<-duck_karyotype[,c("Chr","Start","End")]
chr_id<-read.delim('./data/chrname_change.txt',header=TRUE)
duck_karyotype <- duck_karyotype%>%
  left_join(chr_id,by=c('Chr' = 'old_id'))
duck_karyotype<-duck_karyotype[,c('Chr.y','Start','End')]
names(duck_karyotype)[1] <-'Chr'
duck_karyotype<- duck_karyotype[duck_karyotype$Chr <= 32,]
#gene density
gene_density <- read.delim("./data/pan_gene_density.used.list",header=FALSE)
colnames(gene_density) <-c("Chr","Start","End","Value")
gene_density<- gene_density[gene_density$Chr <= 32,]
ideogram(karyotype = duck_karyotype,overlaid = gene_density,label = duck_marker,label_type = "line",colorset1 = c("#fc8d59", "#ffffbf", "#91bfdb"))
convertSVG("chromosome.svg", device = "png")
svg2pdf("chromosome.svg")





##################
### Figure3B ###
##################
library(ggstatsplot)
#data reading window size = 10 kb
data_10K<- read.csv("./data/pan_final.fa.chr.10k.windowste_sv_combine_subset1.csv")
colnames(data_10K) <-c("ID","TE","SV")
data_10K<-data_10K[complete.cases(data_10K),] ##ȥ��NA ��
P1<-ggpiestats(data= data_10K,x = SV,y = TE,package = "wesanderson",palette = "Royal1",title= "TE",legend.title = "SV")
P1
#data reading window size = 5 kb
data_5K<- read.csv("./data/pan_final.fa.chr.5k.windowste_sv_combine_subset1.csv")
colnames(data_5K) <-c("ID","TE","SV")
P2<-ggpiestats(data= data_5K,x = SV,y = TE,package = "wesanderson",palette = "Royal1",title= "TE",legend.title = "SV")
P2
#data reading window size = 2 kb
data_2K<- read.csv("./data/pan_final.fa.chr.2k.windowste_sv_combine_subset1.csv")
colnames(data_2K) <-c("ID","TE","SV")
P3<-ggpiestats(data= data_2K,x = SV,y = TE,package = "wesanderson",palette = "Royal1",title= "TE",legend.title = "SV")
P3
require(gridExtra)
grid.arrange(P3,P2,P1,ncol=1)








##################
### Figure3D ###
##################
library(ChIPseeker)
library(GenomicFeatures)
library(UpSetR)
library(ggupset)
library(ggimage)
#01.makeTxDbFromGFF
PanDuckGFF <- "./data/PanDuck2.gff"
PanDuckdb <- makeTxDbFromGFF(PanDuckGFF, 
                             format="auto", 
                             dataSource="PanDuck", 
                             organism="Anas platyrhynchos")
#02.TEanno
#SVTE50
PanDuckSVTE50  <- "./data/PanDuckSVTE50.bed"
PanDuckSVTE50Anno <- annotatePeak(PanDuckSVTE50, 
                                  tssRegion=c(-5000, 5000),
                                  TxDb=PanDuckdb,
                                  genomicAnnotationPriority = c("Promoter", "5UTR", "3UTR", "Exon", "Intron", "Downstream", "Intergenic"))


vennpie(PanDuckSVTE50Anno)


