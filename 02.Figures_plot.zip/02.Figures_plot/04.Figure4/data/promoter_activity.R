
mytheme <- theme(#legend.position = "none",
  panel.grid.major = element_blank(),
  panel.grid.minor = element_blank(),
  panel.border = element_blank(),
  panel.background = element_blank(),
  legend.title = element_blank(),
  legend.text = element_text(size = 10, face = "bold.italic"),
  legend.key.height=unit(2,"line"),
  axis.line = element_blank(),
  axis.ticks = element_line(size = 1, colour = "black"),
  axis.ticks.length=unit(.15, "cm"),
  axis.title.x = element_text(face = "bold", size = 15, colour = "black"),
  axis.title.y = element_text(face = "bold", size = 15, colour = "black"),
  axis.text.x = element_text(size = 10,angle = 0, vjust = 0, face = "bold", colour = "black"), 
  axis.text.y = element_text(face = "bold", size = 10, colour = "black"),
  axis.line.x = element_line(colour = "black", size = 0.6),
  axis.line.y = element_line(colour = "black", size = 0.6),
  plot.margin = margin(t = 1, r = 1, b = 0.5, l = 0.5, unit = "cm"))



library(ggplot2)
library(forcats)
library("RColorBrewer")
library("ggsignif")

# ���ù���·�������ݴ�ŵ��ļ�����
setwd("E:\\duck\\14.131_pan\\14.luciferase_assay")
# ������
library(ggpubr)
######transcriptinal activity 
setwd("E:\\duck\\14.131_pan\\14.luciferase_assay")
df<-read.csv('plot4.csv',header = TRUE)
names(df)[1] <-"group"
myclour_Set2 <- c('#BF0B3B','#F2B90C','#238C2A','#D50DD9')
my_comparisons <- list(c("W", "NC"),c("W", "K"),c("NC", "K"))

class(df$expression)
p1 <- ggbarplot(df, x="group", y="value", 
                add = c("mean_sd", "jitter"),
                position = position_dodge(0.3), 
                fill = 'group',
                xlab = 'Promoter type',
                ylab = 'Firefly/Renilla' , rotate=TRUE)+
  mytheme+scale_fill_manual(values = myclour_Set2)+ rotate_x_text(angle = 0)+
  stat_compare_means(comparisons=my_comparisons, method='t.test',label = "p.format")

p1
cowplot::save_plot("prmoter_activity2.pdf",p1,base_height = 8.71,base_asp = 1.4)



