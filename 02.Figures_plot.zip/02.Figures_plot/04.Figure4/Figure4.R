#Author: Kejun Wang
#Email: wangkejun.me@163.com

setwd("/Your/Path/Here")

##################
### Figure4D ###
##################
pie.df <- read.csv("./data/data.csv")
pie.df <- pie.df[, 1:4]
names(pie.df)[1] <- "type"
library(plyr)
par(mfcol = c(4, 3), mai = c(0,0,0,0), mar=c(0,0,0,0),cex =1.5)
for(i in unique(pie.df$type))
  for(j in unique(pie.df$no)){
    # cat(i, j)
    # browser()
    sub.data <- subset(pie.df, type == i & no == j)
    pie.data <- c("Presense" = sub.data$Presence, "Absence" = sub.data$Absence)
    pie(pie.data, labels = "",# main = pie.data[1],
        border = NA, col = c("#238C2A", "#F2B90C"))
  }
par(no.readonly=TRUE)



##################
### Figure4E ###
##################
library(ggplot2)
library(scales)
#IGF2BP1:28, NC_051799.1:74708-111318
data_IGF2BP1 <- read.csv("./data/data_IGF2BP1_01.csv")
data_IGF2BP1_01 <- subset(data_IGF2BP1, CHROM == "28" & 14708 < BIN_START & BIN_START < 401318)
data_IGF2BP1_02 <- subset(data_IGF2BP1, CHROM == "28" & 0 < BIN_START & BIN_START < 1001318)

p11 <- ggplot(data = data_IGF2BP1_01, aes(x=BIN_START/1000000, y=VALUE, color=TYPE))+
  geom_line(size=1.5)+
  scale_color_brewer(palette = "Set1") +
  theme_bw() +
  labs(x="IGF2BP1 (Chr28:0.074-0.11,Mb)", y=NULL) +
  theme(axis.title = element_text(size = 16, face = "bold")) +
  theme(axis.text = element_text(size = 10, face = "bold")) +
  theme(legend.title = element_text(size = 16, face = "bold"), legend.text = element_text(size = 10, face = "bold")) +
  theme(panel.grid = element_blank(), legend.position = "right") +
  facet_wrap(~Group, ncol=1, scales = "free_y") +
  theme(strip.background = element_rect(fill="NA"),
        strip.text = element_text(color="black", face = "bold", size = 12)) +
  annotate('text',x=0.092,y=0.0015,label="IGF2BP1",size=3,color='black') +
  annotate("rect", xmin = 0.074708, xmax = 0.111318, ymin = 0, ymax = 0.002,alpha = 0.2, fill = "blue") +
  annotate('text',x=0.119,y=0.0015,label="Gypsy",size=3,color='red') +
  annotate("rect", xmin = 0.113029, xmax = 0.120138, ymin = 0, ymax = 0.002,alpha = 0.2, fill = "orange")
p11       
ggsave("IGF2BP1_01.pdf", p11, width = 16, height = 12)
ggsave("IGF2BP1_01.png", p11, width = 16, height = 12, dpi=300)



##################
### Figure4F ###
##################
library(readxl)
data <-read.csv("./data/data_F2_phenotype.csv")
#data <- data[data$Genotype != 'NA',]
library("RColorBrewer")
library("ggsignif")
library(ggplot2)
#trait_list2 <-c("CW1","CR","SL12","DPW","BBL12","PB12","LW","BWHR","CW","HW1","SEW","SG12","BSL8","SG8","EW","GW","BW12","BSL12","BW10","BBL8","LMW","BW6","GR0_4")
trait_list <-c('BW0','BW1','BW2','BW3',"BW4","BW5","BW6","BW7","BW8","BW9","BW10","BW11","BWHR","CW","SEW","EW","LW1","BMW","SFW","AFW","SFT")
myvolin_plot <- function(trait){
  df <-data[,c("Genotype","Sex",trait)]
  colnames(df) <-c("Genotype","Sex","Phenotype")
  df$Group<-factor(df$Genotype, levels = c("Presence","Het","Absence"))
  dp_trait <-ggplot(df,aes(x=Group,y=Phenotype, fill=Group))+
    geom_violin(trim=FALSE)+geom_boxplot(width=0.1, fill="white")+
    labs( y = trait)+theme_classic()+
    scale_fill_manual(values = c('#BF0B3B','#D50DD9','#1835D9'))+
    theme(legend.position = "none")+
    facet_wrap(~Sex,scale="free")
  cowplot::save_plot(paste0(trait,"sex.pdf"),dp_trait,base_height = 3.71,base_asp = 1)
}
for (i in trait_list){
  myvolin_plot(i)
}
trait<-"BW8"
df <-data[,c("Genotype","Sex",trait)]
colnames(df) <-c("Genotype","Sex","Phenotype")
df$Group<-factor(df$Genotype, levels = c("Presence","Het","Absence"))
p1 <-ggplot(df,aes(x=Group,y=Phenotype, fill=Group))+  geom_violin(trim=FALSE)+geom_boxplot(width=0.1, fill="white")+ labs( y = trait)+theme_classic()+ scale_fill_manual(values = c('#BF0B3B','#D50DD9','#1835D9'))+ theme(legend.position = "none")+facet_wrap(~Sex,scale="fixed")
p1
trait<-"BW9"
df <-data[,c("Genotype","Sex",trait)]
colnames(df) <-c("Genotype","Sex","Phenotype")
df$Group<-factor(df$Genotype, levels = c("Presence","Het","Absence"))
p2 <-ggplot(df,aes(x=Group,y=Phenotype, fill=Group))+  geom_violin(trim=FALSE)+geom_boxplot(width=0.1, fill="white")+ labs( y = trait)+theme_classic()+ scale_fill_manual(values = c('#BF0B3B','#D50DD9','#1835D9'))+ theme(legend.position = "none")+facet_wrap(~Sex,scale="fixed")
p2
trait<-"BWHR"
df <-data[,c("Genotype","Sex",trait)]
colnames(df) <-c("Genotype","Sex","Phenotype")
df$Group<-factor(df$Genotype, levels = c("Presence","Het","Absence"))
p3 <-ggplot(df,aes(x=Group,y=Phenotype, fill=Group))+  geom_violin(trim=FALSE)+geom_boxplot(width=0.1, fill="white")+ labs( y = trait)+theme_classic()+ scale_fill_manual(values = c('#BF0B3B','#D50DD9','#1835D9'))+ theme(legend.position = "none")+facet_wrap(~Sex,scale="fixed")
p3
trait<-"CW"
df <-data[,c("Genotype","Sex",trait)]
colnames(df) <-c("Genotype","Sex","Phenotype")
df$Group<-factor(df$Genotype, levels = c("Presence","Het","Absence"))
p4 <-ggplot(df,aes(x=Group,y=Phenotype, fill=Group))+  geom_violin(trim=FALSE)+geom_boxplot(width=0.1, fill="white")+ labs( y = trait)+theme_classic()+ scale_fill_manual(values = c('#BF0B3B','#D50DD9','#1835D9'))+ theme(legend.position = "none")+facet_wrap(~Sex,scale="fixed")
p4
trait<-"SEW"
df <-data[,c("Genotype","Sex",trait)]
colnames(df) <-c("Genotype","Sex","Phenotype")
df$Group<-factor(df$Genotype, levels = c("Presence","Het","Absence"))
p5 <-ggplot(df,aes(x=Group,y=Phenotype, fill=Group))+  geom_violin(trim=FALSE)+geom_boxplot(width=0.1, fill="white")+ labs( y = trait)+theme_classic()+ scale_fill_manual(values = c('#BF0B3B','#D50DD9','#1835D9'))+ theme(legend.position = "none")+facet_wrap(~Sex,scale="fixed")
p5
trait<-"EW"
df <-data[,c("Genotype","Sex",trait)]
colnames(df) <-c("Genotype","Sex","Phenotype")
df$Group<-factor(df$Genotype, levels = c("Presence","Het","Absence"))
p6 <-ggplot(df,aes(x=Group,y=Phenotype, fill=Group))+  geom_violin(trim=FALSE)+geom_boxplot(width=0.1, fill="white")+ labs( y = trait)+theme_classic()+ scale_fill_manual(values = c('#BF0B3B','#D50DD9','#1835D9'))+ theme(legend.position = "none")+facet_wrap(~Sex,scale="fixed")
p6
trait<-"LW1"
df <-data[,c("Genotype","Sex",trait)]
colnames(df) <-c("Genotype","Sex","Phenotype")
df$Group<-factor(df$Genotype, levels = c("Presence","Het","Absence"))
p7 <-ggplot(df,aes(x=Group,y=Phenotype, fill=Group))+  geom_violin(trim=FALSE)+geom_boxplot(width=0.1, fill="white")+ labs( y = trait)+theme_classic()+ scale_fill_manual(values = c('#BF0B3B','#D50DD9','#1835D9'))+ theme(legend.position = "none")+facet_wrap(~Sex,scale="fixed")
p7
trait<-"BMW"
df <-data[,c("Genotype","Sex",trait)]
colnames(df) <-c("Genotype","Sex","Phenotype")
df$Group<-factor(df$Genotype, levels = c("Presence","Het","Absence"))
p8 <-ggplot(df,aes(x=Group,y=Phenotype, fill=Group))+  geom_violin(trim=FALSE)+geom_boxplot(width=0.1, fill="white")+ labs( y = trait)+theme_classic()+ scale_fill_manual(values = c('#BF0B3B','#D50DD9','#1835D9'))+ theme(legend.position = "none")+facet_wrap(~Sex,scale="fixed")
p8
require(gridExtra)
pall<-grid.arrange(p1,p2,p3,p4,p5,p6,p7,p8,ncol=4)
cowplot::save_plot("top8trait.pdf",pall,base_height = 9.71,base_asp = 2)



##################
### Figure4G ###
##################
mytheme <- theme(#legend.position = "none",
  panel.grid.major = element_blank(),
  panel.grid.minor = element_blank(),
  panel.border = element_blank(),
  panel.background = element_blank(),
  legend.title = element_blank(),
  legend.text = element_text(size = 10, face = "bold.italic"),
  legend.key.height=unit(2,"line"),
  axis.line = element_blank(),
  axis.ticks = element_line(size = 1, colour = "black"),
  axis.ticks.length=unit(.15, "cm"),
  axis.title.x = element_text(face = "bold", size = 15, colour = "black"),
  axis.title.y = element_text(face = "bold", size = 15, colour = "black"),
  axis.text.x = element_text(size = 10,angle = 0, vjust = 0, face = "bold", colour = "black"), 
  axis.text.y = element_text(face = "bold", size = 10, colour = "black"),
  axis.line.x = element_line(colour = "black", size = 0.6),
  axis.line.y = element_line(colour = "black", size = 0.6),
  plot.margin = margin(t = 1, r = 1, b = 0.5, l = 0.5, unit = "cm"))

library(ggplot2)
library(forcats)
library("RColorBrewer")
library("ggsignif")
library(ggpubr)
#reading file
df<-read.csv('./data/data_promoter_activity.csv',header = TRUE)
names(df)[1] <-"group"
myclour_Set2 <- c('#BF0B3B','#F2B90C','#238C2A','#D50DD9')
my_comparisons <- list(c("W", "NC"),c("W", "K"),c("NC", "K"))
class(df$expression)
p1 <- ggbarplot(df, x="group", y="value", 
                add = c("mean_sd", "jitter"),
                position = position_dodge(0.3), 
                fill = 'group',
                xlab = 'Promoter type',
                ylab = 'Firefly/Renilla' , rotate=TRUE)+
  mytheme+scale_fill_manual(values = myclour_Set2)+ rotate_x_text(angle = 0)+
  stat_compare_means(comparisons=my_comparisons, method='t.test',label = "p.format")
p1
cowplot::save_plot("prmoter_activity.pdf",p1,base_height = 8.71,base_asp = 1.4)


##################
### Figure4H ###
##################
library(tidyverse)
library(ggpubr)
df<-read.csv('./data/data_IGF2BP1_expression.csv',header = TRUE)
names(df)[1] <-"group"
myclour_Set2 <- c('#F2B90C','#238C2A')
my_comparisons <- list(c("WW", "KK"))
df_sub <-df[df$Tissue == 'Breast',]
class(df_sub$expression)
df_sub <-df_sub %>% drop_na(group,expression)
df_sub<-df_sub[df_sub$expression < 10,]
#Breast
p1 <- ggbarplot(df_sub, x="group", y="expression", 
                add = c("mean_sd", "jitter"),
                position = position_dodge(1.0), 
                fill = 'group',
                xlab = 'Breast',
                ylab = 'Relative expression of IGF2BP1' )+
  mytheme+scale_fill_manual(values = myclour_Set2)+ rotate_x_text(angle = 45)+
  stat_compare_means(comparisons=my_comparisons, method='t.test',label = "p.format")
p1

#Liver
df_sub <-df[df$Tissue == 'Liver',]
class(df_sub$expression)
df_sub <-df_sub %>% drop_na(group,expression)
p2 <- ggbarplot(df_sub, x="group", y="expression", 
                add = c("mean_sd", "jitter"),
                position = position_dodge(1.0), 
                fill = 'group',
                xlab = 'Liver',
                ylab = '' )+
  mytheme+scale_fill_manual(values = myclour_Set2)+ rotate_x_text(angle = 45)+
  stat_compare_means(comparisons=my_comparisons,method='t.test',label = "p.fromat")
p2

#Cecum
df_sub <-df[df$Tissue == 'Cecum',]
df_sub <-df_sub %>% drop_na(group,expression)
p3 <- ggbarplot(df_sub, x="group", y="expression", 
                add = c("mean_sd", "jitter"),
                position = position_dodge(1.0), 
                fill = 'group',
                xlab = 'Cecum',
                ylab = '' )+
  mytheme+scale_fill_manual(values = myclour_Set2)+ rotate_x_text(angle = 45)+
  stat_compare_means(comparisons=my_comparisons,method='t.test',label = "p.reformat")
p3

#Duodenum
df_sub <-df[df$Tissue == 'Duodenum',]
df_sub <-df_sub %>% drop_na(group,expression)
p4 <- ggbarplot(df_sub, x="group", y="expression", 
                add = c("mean_sd", "jitter"),
                position = position_dodge(1.0), 
                fill = 'group',
                xlab = 'Duodenum',
                ylab = '' )+
  mytheme+scale_fill_manual(values = myclour_Set2)+ rotate_x_text(angle = 45)+
  stat_compare_means(comparisons=my_comparisons,method='t.test',label = "p.format")
p4

require(gridExtra)
grid.arrange(p3,p4,p1,p2,ncol=4)

