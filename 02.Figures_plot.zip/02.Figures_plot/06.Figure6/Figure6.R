#Author: Kejun Wang
#Email: wangkejun.me@163.com

setwd("/Your/Path/Here")
setwd("E:\\duck\\14.131_pan\\12.ms\\2.toMartien\\13.imeta\\proof\\github_submit\\02.Figures_plot\\06.Figure6")
##################
### Figure6B ###
##################
#ideogram plot
duck_marker_single <-read.csv("./data/data_SV_TE_marker_genome.csv")
duck_marker_single<- duck_marker_single[duck_marker_single$Chr <= 32,]
names(duck_marker_single)[1] <- 'Type'
ideogram(karyotype = duck_karyotype, label = duck_marker_single, label_type = "marker")
convertSVG("chromosome.svg", device = "png")
convertSVG("chromosome.svg", device = "pdf")


#density plot

the <- theme(#legend.position = "none",
  panel.grid.major = element_blank(),
  panel.grid.minor = element_blank(),
  panel.border = element_blank(),
  panel.background = element_blank(),
  legend.title = element_blank(),
  legend.text = element_text(size = 10, face = "bold.italic"),
  legend.key.height=unit(2,"line"),
  axis.line = element_blank(),
  axis.ticks = element_line(size = 1, colour = "black"),
  axis.ticks.length=unit(.15, "cm"),
  axis.title.x = element_text(face = "bold", size = 15, colour = "black"),
  axis.title.y = element_text(face = "bold", size = 15, colour = "black"),
  axis.text.x = element_text(size = 10,angle = 0, vjust = 0, face = "bold", colour = "black"),
  axis.text.y = element_text(face = "bold", size = 10, colour = "black"),
  axis.line.x = element_line(colour = "black", size = 0.6),
  axis.line.y = element_line(colour = "black", size = 0.6),
  plot.margin = margin(t = 1, r = 1, b = 0.5, l = 0.5, unit = "cm"))

library(ggstatsplot)
library(ggplot2)
library(tidyverse)
df<-read.csv('./data/three_clade_color_insert_time.csv')
colnames(df) <-c("Te_name","Insert_Time","TE_Group")
df <- df%>%mutate(Insert_Time_million = Insert_Time/1000000)

#pink
df_pink<- df[df$TE_Group == 'pink',]
g<-ggplot(df_pink,aes(Insert_Time_million))
p1 <- g + the+ geom_density(aes(fill=factor(TE_Group)), alpha=0.8)+labs(title="", subtitle="",x="Insertion Time (year)",y="Length density",fill="#LTR type")
p2 <- p1+scale_fill_manual(values=c('#D50DD9','#F2B90C','#238C2A','#BF0B3B','#1835D9'))
p2

#green
df_green<- df[df$TE_Group == 'green',]
g<-ggplot(df_green,aes(Insert_Time_million))
p3 <- g + the+ geom_density(aes(fill=factor(TE_Group)), alpha=0.8)+labs(title="", subtitle="",x="Insertion Time (million year)",y="Density",fill="#LTR type")
p4 <- p3+scale_fill_manual(values=c('#238C2A','#F2B90C', '#D50DD9', '#BF0B3B','#1835D9'))
p4

#rest
df_rest<- df[df$TE_Group == 'rest',]
g<-ggplot(df_rest,aes(Insert_Time_million))
p5 <- g + the+ geom_density(aes(fill=factor(TE_Group)), alpha=0.8)+labs(title="", subtitle="",x="Insertion Time (million year)",y="Density",fill="#LTR type")
p6 <- p3+scale_fill_manual(values=c('#1835D9','#D50DD9','#238C2A','#F2B90C',  '#BF0B3B'))
p6

require(gridExtra)
pall<-grid.arrange(p2,p4,p6,ncol=3)
