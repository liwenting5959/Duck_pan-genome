#Author: Kejun Wang
#Email: wangkejun.me@163.com

setwd("/Your/Path/Here")

###Figure 1B
the <- theme(#legend.position = "none",
  panel.grid.major = element_blank(),
  panel.grid.minor = element_blank(),
  panel.border = element_blank(),
  panel.background = element_blank(),
  legend.title = element_blank(),
  legend.text = element_text(size = 10, face = "bold.italic"),
  legend.key.height=unit(2,"line"),
  axis.line = element_blank(),
  axis.ticks = element_line(size = 1, colour = "black"),
  axis.ticks.length=unit(.15, "cm"),
  axis.title.x = element_text(face = "bold", size = 15, colour = "black"),
  axis.title.y = element_text(face = "bold", size = 15, colour = "black"),
  axis.text.x = element_text(size = 10,angle = 0, vjust = 0, face = "bold", colour = "black"), 
  axis.text.y = element_text(face = "bold", size = 10, colour = "black"),
  axis.line.x = element_line(colour = "black", size = 0.6),
  axis.line.y = element_line(colour = "black", size = 0.6),
  plot.margin = margin(t = 1, r = 1, b = 0.5, l = 0.5, unit = "cm"))


library(readxl)
library(ggplot2)
#data reading
data<-read_excel("./data/Data.xlsx",sheet = "Figure 1B")
data[["Chr"]] <- factor(data[["Chr"]], levels = as.character(data[["Chr"]]))
#figure plot
p1<-ggplot(data,aes(x=Chr,y=Number))+geom_point(size = 5, shape = 19, color="#238C2A")+the
p1
p2<-ggplot(data,aes(x=Chr,y=Length))+geom_point(size = 5, shape = 19, color="#F2B90C")+scale_y_log10()+the+xlab("")
p2
require(gridExtra)
pall<-grid.arrange(p1,p2,ncol=1)


###Figure 1C

the <- theme(#legend.position = "none",
  panel.grid.major = element_blank(),
  panel.grid.minor = element_blank(),
  panel.border = element_blank(),
  panel.background = element_blank(),
  legend.title = element_blank(),
  legend.text = element_text(size = 10, face = "bold.italic"),
  legend.key.height=unit(2,"line"),
  axis.line = element_blank(),
  axis.ticks = element_line(size = 1, colour = "black"),
  axis.ticks.length=unit(.15, "cm"),
  axis.title.x = element_text(face = "bold", size = 15, colour = "black"),
  axis.title.y = element_text(face = "bold", size = 15, colour = "black"),
  axis.text.x = element_text(size = 10,angle = 0, vjust = 0, face = "bold", colour = "black"), 
  axis.text.y = element_text(face = "bold", size = 10, colour = "black"),
  axis.line.x = element_line(colour = "black", size = 0.6),
  axis.line.y = element_line(colour = "black", size = 0.6),
  plot.margin = margin(t = 1, r = 1, b = 0.5, l = 0.5, unit = "cm"))

library(ggplot2)
#data reading
data<-read_excel("./data/Data.xlsx",sheet = "Figure 1C")
colnames(data)<-c("contig","length")
data$cluster[ 500< data$length & data$length  <= 1000] <-'500-1000'
data$cluster[1000 < data$length & data$length <= 10000] <-'1000-10000'
data$cluster[10000 < data$length & data$length <= 50000] <-'10000-50000'
data$cluster[ 50000< data$length] <-'>50000'
#figure plot
p<-ggplot(data,aes(data$length))+scale_x_log10()+geom_histogram(data=data,aes(x=length,..density..),bins=80,fill='#238C2A',color="white",size=0.9, alpha=1.0)
p1<- p+the+xlab("Length")+ylab("Count")+geom_density(size=1.2,color="#F2B90C",adjust=1/1.2)
p1



###Figure 1E
#function setting
plotCI <- function(x, lwr, upr, col = "grey80", lty = "dashed", borderCol = "red"){
  # browser()
  # lines(c(rev(x), (x)), c(rev(upr),(lwr)))
  polygon(c((x), rev(x)), c((upr),rev(lwr)), col = col, border = NA)
  lines(x, upr, lty = lty, col = borderCol)
  lines(x, lwr, lty = lty, col = borderCol)
}
plotFit <- function(x, y, ...){
  index <- order(x)
  x.o <- x[index]
  y.o <- y[index]
  # browser()
  lines(x = x.o, y = y.o, ...)
}

#data reading
data<-read_excel("./data/Data.xlsx",sheet = "Figure 1E")
plot(core ~ Combinations, data = data, col = "grey", type = "n", ylim = c(15950, 16350))
model.comb.lm <- lm(core ~log10(Combinations), data = data)
#figure plot
preds.comb <- predict(model.comb.lm,  interval = 'confidence')
head(preds.comb)
plotFit(x = data$Combinations, y = preds.comb[,1], col = "red")
model.pan.lm <- lm(pangenome~log10(Combinations), data = data)
preds.pan <- predict(model.pan.lm, interval = 'confidence')
plotFit(x = data$Combinations, y = preds.pan[,1], col = "orange")
head(preds.pan)
tail(preds.pan)

