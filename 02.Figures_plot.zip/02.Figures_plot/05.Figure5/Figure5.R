#Author: Kejun Wang
#Email: wangkejun.me@163.com

setwd("/Your/Path/Here")
setwd("E:/duck/14.131_pan/12.ms/2.toMartien/13.imeta/proof/github_submit/02.Figures_plot/05.Figure5")


##################
### Figure5B ###
##################
pie.df <- read.csv("./data/data_genotype_MITF.csv")
pie.df <- pie.df[, 1:5]
names(pie.df)[1] <- "type"
library(plyr)
par(mfcol = c(5, 3), mai = c(0,0,0,0), mar=c(0,0,0,0),cex =1.5)
for(i in unique(pie.df$type))
  for(j in unique(pie.df$no)){
    # cat(i, j)
    # browser()
    sub.data <- subset(pie.df, type == i & no == j)
    pie.data <- c("Presense" = sub.data$II, "Het" = sub.data$ID,"Absence" = sub.data$DD )
    pie(pie.data, labels = "",# main = pie.data[1],
        border = NA, col = c("#238C2A","#D50DD9", "#F2B90C"))
  }
par(no.readonly=TRUE)


##################
### Figure5C ###
##################
library(ggplot2)
library(scales)
#MITF:13, NC_051784.1:5199191-5304402
data_MITF <- read.csv("./data/data_MITF_01.csv")
data_MITF_01 <- subset(data_MITF, CHROM == "13" & 4878923 < BIN_START & BIN_START < 5582692)
data_MITF_02 <- subset(data_MITF, CHROM == "13" & 4078923 < BIN_START & BIN_START < 6082692)
p21 <- ggplot(data = data_MITF_01, aes(x=BIN_START/1000000, y=VALUE, color=TYPE))+
  geom_line(size=1.0)+
  scale_color_brewer(palette = "Set1") +
  theme_bw() +
  labs(x="MITF (Chr13:5.19-5.30,Mb)", y=NULL) +
  theme(axis.title = element_text(size = 16, face = "bold")) +
  theme(axis.text = element_text(size = 10, face = "bold")) +
  theme(legend.title = element_text(size = 16, face = "bold"), legend.text = element_text(size = 10, face = "bold")) +
  theme(panel.grid = element_blank(), legend.position = "right") +
  facet_wrap(~Group, ncol=1, scales = "free_y") +
  theme(strip.background = element_rect(fill='NA'),
        strip.text = element_text(color="black", face = "bold", size = 12)) +
  annotate('text',x=5.25,y=0.015,label="MITF",size=3,color='black') +
  annotate("rect", xmin = 5.19, xmax = 5.30, ymin = 0, ymax = 0.02,alpha = 0.1, fill = "blue") +
  annotate('text',x=5.22,y=0.01,label="Gypsy",size=3,color='red') +
  annotate("rect", xmin = 5.220761, xmax = 5.227457, ymin = 0, ymax = 0.02,alpha = 0.2, fill = "orange")
p21      

ggsave("MITF_01.pdf", p21, width = 16, height = 12)
ggsave("MITF_01.png", p21, width = 16, height = 12, dpi=300)


##################
### Figure5H ###
##################

mytheme <- theme(#legend.position = "none",
  panel.grid.major = element_blank(),
  panel.grid.minor = element_blank(),
  panel.border = element_blank(),
  panel.background = element_blank(),
  legend.title = element_blank(),
  legend.text = element_text(size = 10, face = "bold.italic"),
  legend.key.height=unit(2,"line"),
  axis.line = element_blank(),
  axis.ticks = element_line(size = 1, colour = "black"),
  axis.ticks.length=unit(.15, "cm"),
  axis.title.x = element_text(face = "bold", size = 15, colour = "black"),
  axis.title.y = element_text(face = "bold", size = 15, colour = "black"),
  axis.text.x = element_text(size = 10,angle = 0, vjust = 0, face = "bold", colour = "black"), 
  axis.text.y = element_text(face = "bold", size = 10, colour = "black"),
  axis.line.x = element_line(colour = "black", size = 0.6),
  axis.line.y = element_line(colour = "black", size = 0.6),
  plot.margin = margin(t = 1, r = 1, b = 0.5, l = 0.5, unit = "cm"))

library(readxl)
library(ggpubr)
library(ggplot2)
df<-read.csv('./data/MITF-Overexpression-cells-expression-level.csv')
names(df)[1] <-"expression"
myclour_Set2 <- c('#F2B90C','#238C2A','#D50DD9')
my_comparisons <- list(c("MITF-M","MITF-Novel"),c("Blank", "MITF-Novel"),c("Blank", "MITF-M"))
#TYR
df_sub <-df[df$gene == 'TYR',]
class(df_sub$expression)
p2 <- ggboxplot(df_sub, x="breed", y="expression", 
                add = c("mean_sd", "jitter"),
                #position = position_dodge(1.0), 
                fill = 'breed',
                xlab = ' ',
                ylab = 'Relative expression of TYR' )+
  mytheme+scale_fill_manual(values = myclour_Set2)+ rotate_x_text(angle = 45)+
  stat_compare_means(comparisons=my_comparisons, method='t.test',label = "p.format")
p2
#TYRP1
df_sub <-df[df$gene == 'TYRP1',]
class(df_sub$expression)
p3 <- ggboxplot(df_sub, x="breed", y="expression", 
                add = c("mean_sd", "jitter"),
                #position = position_dodge(1.0), 
                fill = 'breed',
                xlab = ' ',
                ylab = 'Relative expression of TYRP1' )+
  mytheme+scale_fill_manual(values = myclour_Set2)+ rotate_x_text(angle = 45)+
  stat_compare_means(comparisons=my_comparisons, method='t.test',label = "p.format")
p3

#MLANA
df_sub <-df[df$gene == 'MLANA',]
class(df_sub$expression)
p5 <- ggboxplot(df_sub, x="breed", y="expression", 
                add = c("mean_sd", "jitter"),
                #position = position_dodge(1.0), 
                fill = 'breed',
                xlab = ' ',
                ylab = 'Relative expression of MLANA' )+
  mytheme+scale_fill_manual(values = myclour_Set2)+ rotate_x_text(angle = 45)+
  stat_compare_means(comparisons=my_comparisons, method='t.test',label = "p.format")
p5

#OCA2
df_sub <-df[df$gene == 'OCA2',]
class(df_sub$expression)
p6 <- ggboxplot(df_sub, x="breed", y="expression", 
                add = c("mean_sd", "jitter"),
                #position = position_dodge(1.0), 
                fill = 'breed',
                xlab = ' ',
                ylab = 'Relative expression of OCA2' )+
  mytheme+scale_fill_manual(values = myclour_Set2)+ rotate_x_text(angle = 45)+
  stat_compare_means(comparisons=my_comparisons, method='t.test',label = "p.format")
p6
require(gridExtra)
pall<-grid.arrange(p2,p3,p5,p6,ncol=4)
cowplot::save_plot("MITF-transcript-overexpression.pdf",pall,base_height = 9.7,base_asp = 2.6)



