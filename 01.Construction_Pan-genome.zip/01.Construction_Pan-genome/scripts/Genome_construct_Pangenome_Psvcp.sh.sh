#!/bin/bash

# Usage: bash $0 ref.fa query.fa
# Author: Jian Wang
# Email: wjian@gdaas.cn

script_dir=${0%/*}
ref_fa=${1##*/}  #del the path of the file
query_fa=${2##*/}
ref_genome_dir=${1%/*}
query_genome_dir=${2%/*}
prefix_base=${ref_fa%.fa}_${query_fa%.fa}
echo "if [ ! -d 'temp' ]; then mkdir temp; fi"
echo "mkdir ${ref_genome_dir}/$prefix_base ${ref_genome_dir}/$prefix_base/temp"
echo "nucmer -t 100  --maxgap 500 --mincluster 1000 --diagdiff 20 $1 $2 --prefix ${ref_genome_dir}/${prefix_base}/$prefix_base"
echo "echo '1 nucmer ok'"
echo "Assemblytics ${ref_genome_dir}/${prefix_base}/${prefix_base}.delta ${ref_genome_dir}/${prefix_base}/${prefix_base}.bed   1000 50 10000000"
python3 ${script_dir}/construct_pan_script/2variants_to_coords.bed.py ${query_fa%.fa} ${ref_genome_dir}/${prefix_base}/${prefix_base}.bed.Assemblytics_structural_variants.bed ${ref_genome_dir}/${prefix_base}/${prefix_base}.coords.bed
echo "echo '2 Assemblytics ok'"
echo "python3 ${script_dir}/construct_pan_script/3replace_regions_with_nucleotides1.2.py ${ref_genome_dir}/${prefix_base}/${prefix_base}.coords.bed $1 $2 $prefix_base > ${ref_genome_dir}/${prefix_base}/${prefix_base}.final.bed"
echo "echo '3 final.bed ok'"
echo "grep Deletion ${ref_genome_dir}/${prefix_base}/${prefix_base}.final.bed > ${ref_genome_dir}/${prefix_base}/${prefix_base}.del.bed"
echo "grep Insertion ${ref_genome_dir}/${prefix_base}/${prefix_base}.final.bed > ${ref_genome_dir}/${prefix_base}/${prefix_base}.ins.bed"
python3 ${script_dir}/construct_pan_script/4ins_more_50.py ${ref_genome_dir}/${prefix_base}/${prefix_base}.ins.bed ${ref_genome_dir}/${prefix_base}/${prefix_base}.ins.more_50.bed_pre
echo "echo '4 more_50.bed ok'"
echo "cat ${ref_genome_dir}/${prefix_base}/${prefix_base}.ins.more_50.bed_pre|grep -v 'NNNNNNNNNNNNNNNNNNNNNNNNNNNNNN'|grep -v 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'|grep -v 'ttttttttttttttttttttttttttttt'|grep -v 'gggggggggggggggggggggggggggggg'|grep -v 'cccccccccccccccccccccccccccccc' >${ref_genome_dir}/${prefix_base}/${prefix_base}.ins.more_50.bed"
echo "python3 ${script_dir}/construct_pan_script/5ins.bed_to_bed2_kejun.py ${ref_genome_dir}/${prefix_base}/${prefix_base}.ins.more_50.bed"
echo "echo '5 more_50.bed2 ok'"
echo "python3 ${script_dir}/construct_pan_script/6update_ref_by_nucmer.py $1 ${ref_genome_dir}/${prefix_base}/${prefix_base}.ins.more_50.bed2 ${ref_genome_dir}/${ref_fa%.fa}${query_fa%.fa}.fa"
echo "echo '6 6update_ref_by_nucmer.py ok'"
