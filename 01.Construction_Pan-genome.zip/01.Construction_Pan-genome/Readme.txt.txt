#This pipeline used to construct the duck linear pan-genome using a combination approach of Psvcp and PPsPCP pipelines.
